import pandas as pd
import os

files = os.listdir()
files = [x for x in files if ".csv" in x]

for x in files:

    # Reload the original dataset
    file_path = x  # replace with your actual original file name
    df = pd.read_csv(file_path)

    # Display the first few rows to verify the data
    print(df.head())

    # Save a copy of the original data as a backup
    backup_file_path = f"backup/{x}"
    df.to_csv(backup_file_path, index=False)
    print(f"Backup of the original dataset saved to {backup_file_path}")
